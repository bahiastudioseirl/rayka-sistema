import{a}from"./axiosInstance-BCBNuKJi.js";const s=async()=>(await a.get("capacitaciones")).data;export{s as o};
