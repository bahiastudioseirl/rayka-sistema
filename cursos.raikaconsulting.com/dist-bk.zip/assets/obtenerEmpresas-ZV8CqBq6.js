import{a as s}from"./axiosInstance-BCBNuKJi.js";const e=async()=>(await s.get("empresas")).data;export{e as o};
