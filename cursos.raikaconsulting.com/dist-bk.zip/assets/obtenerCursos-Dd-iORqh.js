import{a as s}from"./axiosInstance-BCBNuKJi.js";const r=async()=>(await s.get("cursos")).data;export{r as o};
